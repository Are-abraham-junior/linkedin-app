import { Router } from "express";
import { requireAuth } from "../middlewares/auth.middleware.js";
import {
  getLists,
  createList,
  updateList,
  deleteList,
} from "../controllers/list.controller.js";

const router = Router();

router.use(requireAuth);

router.get("/", getLists);
router.post("/", createList);
router.put("/:id", updateList);
router.delete("/:id", deleteList);

export default router;
